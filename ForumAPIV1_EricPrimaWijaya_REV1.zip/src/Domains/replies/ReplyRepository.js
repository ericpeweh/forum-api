class ReplyRepository {
	async addReply(userId, createReply) {
		throw new Error("REPLY_REPOSITORY.METHOD_NOT_IMPLEMENTED");
	}

	async checkIfReplyExist(replyId, commentId) {
		throw new Error("REPLY_REPOSITORY.METHOD_NOT_IMPLEMENTED");
	}

	async validateReplyOwner(replyId, userId) {
		throw new Error("REPLY_REPOSITORY.METHOD_NOT_IMPLEMENTED");
	}

	async deleteReply(replyId, deleteReply) {
		throw new Error("REPLY_REPOSITORY.METHOD_NOT_IMPLEMENTED");
	}
}

module.exports = ReplyRepository;
