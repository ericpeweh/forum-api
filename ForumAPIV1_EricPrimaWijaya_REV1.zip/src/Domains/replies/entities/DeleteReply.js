class DeleteReply {
	constructor(payload) {
		this._verifyPayload(payload);

		const { commentId, replyId } = payload;

		this.commentId = commentId;
		this.replyId = replyId;
	}

	_verifyPayload({ commentId, replyId }) {
		if (!commentId || !replyId) {
			throw new Error("DELETE_REPLY.NOT_CONTAIN_NEEDED_PROPERTY");
		}

		if (typeof commentId !== "string" || typeof replyId !== "string") {
			throw new Error("DELETE_REPLY.NOT_MEET_DATA_TYPE_SPECIFICATION");
		}
	}
}

module.exports = DeleteReply;
