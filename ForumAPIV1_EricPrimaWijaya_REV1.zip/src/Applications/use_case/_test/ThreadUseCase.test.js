const UsersTableTestHelper = require("../../../../tests/UsersTableTestHelper");
const CreatedThread = require("../../../Domains/threads/entities/CreatedThread");
const CreateThread = require("../../../Domains/threads/entities/CreateThread");
const ThreadRepository = require("../../../Domains/threads/ThreadRepository");
const CommentRepository = require("../../../Domains/comments/CommentRepository");
const ThreadUseCase = require("../ThreadUseCase");
const CommentDetails = require("../../../Domains/comments/entities/CommentDetails");
const ReplyDetails = require("../../../Domains/replies/entities/ReplyDetails");

describe("ThreadUseCase", () => {
	beforeAll(async () => {
		await UsersTableTestHelper.addUser({});
	});

	afterAll(async () => {
		await UsersTableTestHelper.cleanTable();
	});

	it("should orchestrating the add thread action correctly", async () => {
		// Arrange
		const useCasePayload = {
			title: "thread title",
			body: "thread body"
		};
		const userId = "user-123";

		const mockCreatedThread = new CreatedThread({
			id: "thread-123",
			title: useCasePayload.title,
			body: useCasePayload.body,
			owner: userId
		});

		// Create dependency of use case
		const mockThreadRepository = new ThreadRepository();

		// Mock needed function
		mockThreadRepository.addThread = jest
			.fn()
			.mockImplementation(() => Promise.resolve(mockCreatedThread));

		// Create use case instance
		const threadUseCase = new ThreadUseCase({ threadRepository: mockThreadRepository });

		// Action
		const createdThread = await threadUseCase.addThread(userId, useCasePayload);

		// Assert
		expect(createdThread).toStrictEqual(
			new CreatedThread({
				id: "thread-123",
				title: useCasePayload.title,
				owner: userId
			})
		);

		expect(mockThreadRepository.addThread).toBeCalledWith(
			userId,
			new CreateThread({
				title: useCasePayload.title,
				body: useCasePayload.body
			})
		);
	});

	it("should orchestrating the get thread details action correctly", async () => {
		// Arrange
		const useCasePayload = {
			threadId: "thread-123"
		};

		const mockThreadDetails = {
			id: "thread-123",
			title: "thread title",
			body: "thread body",
			date: "2023-01-01T12:00:00.000Z",
			username: "dicoding"
		};

		const mockCommentReplies = [
			{
				id: "reply-123",
				username: "dicoding",
				date: "2023-01-01T12:00:00.000Z",
				content: "sebuah reply",
				is_delete: false
			},
			{
				id: "reply-234",
				username: "dicoding 2",
				date: "2023-01-01T12:00:00.000Z",
				content: "sebuah reply",
				is_delete: true
			}
		];

		const mockThreadComments = [
			{
				id: "comment-123",
				username: "dicoding",
				date: "2023-01-01T12:00:00.000Z",
				content: "sebuah comment",
				replies: mockCommentReplies,
				is_delete: false
			},
			{
				id: "comment-234",
				username: "dicoding 2",
				date: "2023-01-01T12:00:00.000Z",
				content: "sebuah comment",
				replies: [],
				is_delete: true
			}
		];

		const mockResultComments = mockThreadComments.map(comment => {
			const mappedComment = new CommentDetails(comment);
			const mappedReplies = comment.replies.map(reply => new ReplyDetails(reply));

			return { ...mappedComment, replies: mappedReplies };
		});

		// Create dependency of use case
		const mockThreadRepository = new ThreadRepository();
		const mockCommentRepository = new CommentRepository();

		// Mock needed function
		mockThreadRepository.checkIfThreadExist = jest
			.fn()
			.mockImplementation(() => Promise.resolve(true));

		mockThreadRepository.getThreadDetails = jest
			.fn()
			.mockImplementation(() => Promise.resolve(mockThreadDetails));

		mockCommentRepository.getThreadComments = jest
			.fn()
			.mockImplementation(() => Promise.resolve(mockThreadComments));

		// Create use case instance
		const threadUseCase = new ThreadUseCase({
			threadRepository: mockThreadRepository,
			commentRepository: mockCommentRepository
		});

		// Action
		const threadDetails = await threadUseCase.getThreadDetails(useCasePayload);

		// Assert
		expect(threadDetails).toEqual({
			...mockThreadDetails,
			comments: mockResultComments
		});

		expect(mockThreadRepository.checkIfThreadExist).toBeCalledWith(useCasePayload.threadId);

		expect(mockThreadRepository.getThreadDetails).toBeCalledWith(useCasePayload.threadId);

		expect(mockCommentRepository.getThreadComments).toBeCalledWith(useCasePayload.threadId);
	});

	it("should throw not found error if thread is not found on get thread details", async () => {
		// Arrange
		const useCasePayload = {
			threadId: "thread-123"
		};

		// Create dependency of use case
		const mockCommentRepository = new CommentRepository();
		const mockThreadRepository = new ThreadRepository();

		// Mock needed function
		mockThreadRepository.checkIfThreadExist = jest
			.fn()
			.mockImplementation(() => Promise.resolve(false));

		// Create use case instance
		const threadUseCase = new ThreadUseCase({
			threadRepository: mockThreadRepository,
			commentRepository: mockCommentRepository
		});

		// Action and assert
		await expect(threadUseCase.getThreadDetails(useCasePayload)).rejects.toThrowError(
			`Thread dengan id '${useCasePayload.threadId}' tidak ditemukan!`
		);

		expect(mockThreadRepository.checkIfThreadExist).toBeCalledWith(useCasePayload.threadId);
	});
});
