const UsersTableTestHelper = require("../../../../tests/UsersTableTestHelper");
const CreatedComment = require("../../../Domains/comments/entities/CreatedComment");
const CreateComment = require("../../../Domains/comments/entities/CreateComment");
const CommentRepository = require("../../../Domains/comments/CommentRepository");
const CommentUseCase = require("../CommentUseCase");
const ThreadRepository = require("../../../Domains/threads/ThreadRepository");
const DeleteComment = require("../../../Domains/comments/entities/DeleteComment");

describe("CommentUseCase", () => {
	beforeAll(async () => {
		await UsersTableTestHelper.addUser({});
	});

	afterAll(async () => {
		await UsersTableTestHelper.cleanTable();
	});

	it("should orchestrating the add comment action correctly", async () => {
		// Arrange
		const useCasePayload = {
			content: "comment content",
			threadId: "thread-123"
		};
		const userId = "user-123";

		const mockCreatedComment = new CreatedComment({
			id: "comment-123",
			content: "comment content",
			owner: "user-123"
		});

		// Create dependency of use case
		const mockCommentRepository = new CommentRepository();
		const mockThreadRepository = new ThreadRepository();

		// Mock needed function
		mockThreadRepository.checkIfThreadExist = jest
			.fn()
			.mockImplementation(() => Promise.resolve(true));

		mockCommentRepository.addComment = jest
			.fn()
			.mockImplementation(() => Promise.resolve(mockCreatedComment));

		// Create use case instance
		const commentUseCase = new CommentUseCase({
			commentRepository: mockCommentRepository,
			threadRepository: mockThreadRepository
		});

		// Action
		const createdComment = await commentUseCase.addComment(userId, useCasePayload);

		// Assert
		expect(createdComment).toStrictEqual(
			new CreatedComment({
				id: "comment-123",
				content: useCasePayload.content,
				owner: userId
			})
		);

		expect(mockThreadRepository.checkIfThreadExist).toBeCalledWith(useCasePayload.threadId);

		expect(mockCommentRepository.addComment).toBeCalledWith(
			userId,
			new CreateComment({
				content: useCasePayload.content,
				threadId: useCasePayload.threadId
			})
		);
	});

	it("should throw not found error if thread is not found on add comment", async () => {
		// Arrange
		const useCasePayload = {
			content: "comment content",
			threadId: "thread-456" // not existing thread
		};
		const userId = "user-123";

		// Create dependency of use case
		const mockCommentRepository = new CommentRepository();
		const mockThreadRepository = new ThreadRepository();

		// Mock needed function
		mockThreadRepository.checkIfThreadExist = jest
			.fn()
			.mockImplementation(() => Promise.resolve(false));

		// Create use case instance
		const commentUseCase = new CommentUseCase({
			commentRepository: mockCommentRepository,
			threadRepository: mockThreadRepository
		});

		// Action and assert
		await expect(commentUseCase.addComment(userId, useCasePayload)).rejects.toThrowError(
			`Thread dengan id '${useCasePayload.threadId}' tidak ditemukan!`
		);

		expect(mockThreadRepository.checkIfThreadExist).toBeCalledWith(useCasePayload.threadId);
	});

	it("should orchestrating the delete comment action correctly", async () => {
		// Arrange
		const useCasePayload = {
			threadId: "thread-123",
			commentId: "comment-123"
		};
		const userId = "user-123";

		// Create dependency of use case
		const mockCommentRepository = new CommentRepository();
		const mockThreadRepository = new ThreadRepository();

		// Mock needed function
		mockThreadRepository.checkIfThreadExist = jest
			.fn()
			.mockImplementation(() => Promise.resolve(true));

		mockCommentRepository.checkIfCommentExist = jest
			.fn()
			.mockImplementation(() => Promise.resolve(true));

		mockCommentRepository.validateCommentOwner = jest
			.fn()
			.mockImplementation(() => Promise.resolve(true));

		mockCommentRepository.deleteComment = jest.fn().mockImplementation(() => Promise.resolve());

		// Create use case instance
		const commentUseCase = new CommentUseCase({
			commentRepository: mockCommentRepository,
			threadRepository: mockThreadRepository
		});

		// Action
		await commentUseCase.deleteComment(userId, useCasePayload);

		// Assert
		expect(mockThreadRepository.checkIfThreadExist).toBeCalledWith(useCasePayload.threadId);

		expect(mockCommentRepository.checkIfCommentExist).toBeCalledWith(
			useCasePayload.commentId,
			useCasePayload.threadId
		);

		expect(mockCommentRepository.validateCommentOwner).toBeCalledWith(
			useCasePayload.commentId,
			userId
		);

		expect(mockCommentRepository.deleteComment).toBeCalledWith(
			userId,
			new DeleteComment({
				threadId: useCasePayload.threadId,
				commentId: useCasePayload.commentId
			})
		);
	});

	it("should throw not found error if thread is not found on delete comment", async () => {
		// Arrange
		const useCasePayload = {
			threadId: "thread-456", // not existing thread
			commentId: "comment-123"
		};
		const userId = "user-123";

		// Create dependency of use case
		const mockCommentRepository = new CommentRepository();
		const mockThreadRepository = new ThreadRepository();

		// Mock needed function
		mockThreadRepository.checkIfThreadExist = jest
			.fn()
			.mockImplementation(() => Promise.resolve(false));

		// Create use case instance
		const commentUseCase = new CommentUseCase({
			commentRepository: mockCommentRepository,
			threadRepository: mockThreadRepository
		});

		// Action and assert
		await expect(commentUseCase.deleteComment(userId, useCasePayload)).rejects.toThrowError(
			`Thread dengan id '${useCasePayload.threadId}' tidak ditemukan!`
		);

		expect(mockThreadRepository.checkIfThreadExist).toBeCalledWith(useCasePayload.threadId);
	});

	it("should throw not found error if comment is not found on delete comment", async () => {
		// Arrange
		const useCasePayload = {
			threadId: "thread-123",
			commentId: "comment-456" // not existing comment
		};
		const userId = "user-123";

		// Create dependency of use case
		const mockCommentRepository = new CommentRepository();
		const mockThreadRepository = new ThreadRepository();

		// Mock needed function
		mockThreadRepository.checkIfThreadExist = jest
			.fn()
			.mockImplementation(() => Promise.resolve(true));

		mockCommentRepository.checkIfCommentExist = jest
			.fn()
			.mockImplementation(() => Promise.resolve(false));

		// Create use case instance
		const commentUseCase = new CommentUseCase({
			commentRepository: mockCommentRepository,
			threadRepository: mockThreadRepository
		});

		// Action and assert
		await expect(commentUseCase.deleteComment(userId, useCasePayload)).rejects.toThrowError(
			`Komentar dengan id '${useCasePayload.commentId}' pada id thread '${useCasePayload.threadId}' tidak ditemukan!`
		);

		expect(mockThreadRepository.checkIfThreadExist).toBeCalledWith(useCasePayload.threadId);

		expect(mockCommentRepository.checkIfCommentExist).toBeCalledWith(
			useCasePayload.commentId,
			useCasePayload.threadId
		);
	});

	it("should throw authorization error if user is not owner of the comment", async () => {
		// Arrange
		const useCasePayload = {
			threadId: "thread-123",
			commentId: "comment-123"
		};
		const userId = "user-456"; // not comment owner

		// Create dependency of use case
		const mockCommentRepository = new CommentRepository();
		const mockThreadRepository = new ThreadRepository();

		// Mock needed function
		mockThreadRepository.checkIfThreadExist = jest
			.fn()
			.mockImplementation(() => Promise.resolve(true));

		mockCommentRepository.checkIfCommentExist = jest
			.fn()
			.mockImplementation(() => Promise.resolve(true));

		mockCommentRepository.validateCommentOwner = jest
			.fn()
			.mockImplementation(() => Promise.resolve(false));

		// Create use case instance
		const commentUseCase = new CommentUseCase({
			commentRepository: mockCommentRepository,
			threadRepository: mockThreadRepository
		});

		// Action and assert
		await expect(commentUseCase.deleteComment(userId, useCasePayload)).rejects.toThrowError(
			`Gagal menghapus komentar, akses ditolak!`
		);

		expect(mockThreadRepository.checkIfThreadExist).toBeCalledWith(useCasePayload.threadId);

		expect(mockCommentRepository.checkIfCommentExist).toBeCalledWith(
			useCasePayload.commentId,
			useCasePayload.threadId
		);

		expect(mockCommentRepository.validateCommentOwner).toBeCalledWith(
			useCasePayload.commentId,
			userId
		);
	});
});
