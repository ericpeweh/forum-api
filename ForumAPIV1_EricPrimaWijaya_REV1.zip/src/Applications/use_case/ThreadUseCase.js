const NotFoundError = require("../../Commons/exceptions/NotFoundError");
const ReplyDetails = require("../../Domains/replies/entities/ReplyDetails");
const CommentDetails = require("../../Domains/comments/entities/CommentDetails");
const CreateThread = require("../../Domains/threads/entities/CreateThread");

class ThreadUseCase {
	constructor({ threadRepository, commentRepository }) {
		this._threadRepository = threadRepository;
		this._commentRepository = commentRepository;
	}

	async addThread(userId, useCasePayload) {
		const createThread = new CreateThread(useCasePayload);
		const createdThread = await this._threadRepository.addThread(userId, createThread);

		return createdThread;
	}

	async getThreadDetails(useCasePayload) {
		const { threadId } = useCasePayload;

		// Check if thread exist
		const isThreadExist = await this._threadRepository.checkIfThreadExist(threadId);

		if (!isThreadExist) {
			throw new NotFoundError(`Thread dengan id '${threadId}' tidak ditemukan!`);
		}

		const threadDetails = await this._threadRepository.getThreadDetails(threadId);
		const threadComments = await this._commentRepository.getThreadComments(threadId);

		// Map comments and replies data
		const structuredComments = threadComments.map(comment => {
			const mappedReplies = comment.replies.map(reply => new ReplyDetails(reply));
			const mappedComment = new CommentDetails(comment);

			return { ...mappedComment, replies: mappedReplies };
		});

		return {
			...threadDetails,
			comments: structuredComments
		};
	}
}

module.exports = ThreadUseCase;
