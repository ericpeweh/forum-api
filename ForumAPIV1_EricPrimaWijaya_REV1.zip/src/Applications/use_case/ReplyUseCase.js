const AuthorizationError = require("../../Commons/exceptions/AuthorizationError");
const NotFoundError = require("../../Commons/exceptions/NotFoundError");
const CreateReply = require("../../Domains/replies/entities/CreateReply");
const DeleteReply = require("../../Domains/replies/entities/DeleteReply");

class ReplyUseCase {
	constructor({ replyRepository, commentRepository, threadRepository }) {
		this._replyRepository = replyRepository;
		this._commentRepository = commentRepository;
		this._threadRepository = threadRepository;
	}

	async addReply(userId, useCasePayload) {
		const { threadId, commentId, content } = useCasePayload;

		// Validate thread is exist
		const isThreadExist = await this._threadRepository.checkIfThreadExist(threadId);

		if (!isThreadExist) {
			throw new NotFoundError(`Thread dengan id '${threadId}' tidak ditemukan!`);
		}

		// Validate comment exist
		const isCommentExist = await this._commentRepository.checkIfCommentExist(commentId, threadId);

		if (!isCommentExist) {
			throw new NotFoundError(
				`Komentar dengan id '${commentId}' pada id thread '${threadId}' tidak ditemukan!`
			);
		}

		const createReply = new CreateReply({ commentId, content });
		const reply = await this._replyRepository.addReply(userId, createReply);

		return reply;
	}

	async deleteReply(userId, useCasePayload) {
		const { replyId, commentId, threadId } = useCasePayload;

		// Validate thread is exist
		const isThreadExist = await this._threadRepository.checkIfThreadExist(threadId);

		if (!isThreadExist) {
			throw new NotFoundError(`Thread dengan id '${threadId}' tidak ditemukan!`);
		}

		// Validate comment exist
		const isCommentExist = await this._commentRepository.checkIfCommentExist(commentId, threadId);

		if (!isCommentExist) {
			throw new NotFoundError(
				`Komentar dengan id '${commentId}' pada id thread '${threadId}' tidak ditemukan!`
			);
		}

		// Validate reply exist
		const isReplyExist = await this._replyRepository.checkIfReplyExist(replyId, commentId);

		if (!isReplyExist) {
			throw new NotFoundError(
				`Balasan dengan id '${replyId}' pada id komentar '${commentId}' tidak ditemukan!`
			);
		}

		// Validate reply owner
		const isReplyOwner = await this._replyRepository.validateReplyOwner(replyId, userId);

		if (!isReplyOwner) {
			throw new AuthorizationError(`Gagal menghapus balasan, akses ditolak!`);
		}

		const deleteReply = new DeleteReply(useCasePayload);
		await this._replyRepository.deleteReply(userId, deleteReply);
	}
}

module.exports = ReplyUseCase;
