const CreateComment = require("../../Domains/comments/entities/CreateComment");
const NotFoundError = require("../../Commons/exceptions/NotFoundError");
const AuthorizationError = require("../../Commons/exceptions/AuthorizationError");
const DeleteComment = require("../../Domains/comments/entities/DeleteComment");

class CommentUseCase {
	constructor({ commentRepository, threadRepository }) {
		this._commentRepository = commentRepository;
		this._threadRepository = threadRepository;
	}

	async addComment(userId, useCasePayload) {
		// Validate thread is exist
		const { threadId } = useCasePayload;

		const isExist = await this._threadRepository.checkIfThreadExist(threadId);

		if (!isExist) {
			throw new NotFoundError(`Thread dengan id '${threadId}' tidak ditemukan!`);
		}

		const createComment = new CreateComment(useCasePayload);
		const comment = await this._commentRepository.addComment(userId, createComment);

		return comment;
	}

	async deleteComment(userId, useCasePayload) {
		const { threadId, commentId } = useCasePayload;

		// Validate thread is exist
		const isThreadExist = await this._threadRepository.checkIfThreadExist(threadId);

		if (!isThreadExist) {
			throw new NotFoundError(`Thread dengan id '${threadId}' tidak ditemukan!`);
		}

		// Validate comment exist
		const isCommentExist = await this._commentRepository.checkIfCommentExist(commentId, threadId);

		if (!isCommentExist) {
			throw new NotFoundError(
				`Komentar dengan id '${commentId}' pada id thread '${threadId}' tidak ditemukan!`
			);
		}

		// Validate comment owner
		const isCommentOwner = await this._commentRepository.validateCommentOwner(commentId, userId);

		if (!isCommentOwner) {
			throw new AuthorizationError(`Gagal menghapus komentar, akses ditolak!`);
		}

		const deleteComment = new DeleteComment(useCasePayload);
		await this._commentRepository.deleteComment(userId, deleteComment);
	}
}

module.exports = CommentUseCase;
