const ThreadsTableTestHelper = require("../../../../tests/ThreadsTableTestHelper");
const InvariantError = require("../../../Commons/exceptions/InvariantError");
const CreateThread = require("../../../Domains/threads/entities/CreateThread");
const CreatedThread = require("../../../Domains/threads/entities/CreatedThread");
const pool = require("../../database/postgres/pool");
const ThreadRepositoryPostgres = require("../ThreadRepositoryPostgres");
const UsersTableTestHelper = require("../../../../tests/UsersTableTestHelper");

describe("ThreadRepositoryPostgres", () => {
	beforeAll(async () => {
		// Insert new user to users table (Owner of new thread)
		await UsersTableTestHelper.addUser({}); // id of user-123
	});

	afterEach(async () => {
		await ThreadsTableTestHelper.cleanTable();
	});

	afterAll(async () => {
		await UsersTableTestHelper.cleanTable();
		await pool.end();
	});

	describe("addThread function", () => {
		it("should persist create thread and return created thread correctly", async () => {
			// Arrange
			const createThread = new CreateThread({
				title: "thread title",
				body: "thread body"
			});
			const userId = "user-123";
			const fakeIdGenerator = () => "123";
			const threadRepositoryPostgres = new ThreadRepositoryPostgres(pool, fakeIdGenerator);

			// Action
			await threadRepositoryPostgres.addThread(userId, createThread);

			// Assert
			const thread = await ThreadsTableTestHelper.findThreadsById("thread-123");
			expect(thread).toHaveLength(1);
		});
	});

	describe("checkIfThreadExist function", () => {
		it("should return true if thread with given id is found", async () => {
			// Arrange
			const threadRepositoryPostgres = new ThreadRepositoryPostgres(pool, () => {});
			const threadId = "thread-123";

			// Insert thread to table with id of "thread-123"
			await ThreadsTableTestHelper.addThread({});

			// Action
			const isExist = await threadRepositoryPostgres.checkIfThreadExist(threadId);
			expect(isExist).toBe(true);
		});

		it("should return false if thread with given id not exist", async () => {
			// Arrange
			const threadRepositoryPostgres = new ThreadRepositoryPostgres(pool, () => {});
			const threadId = "thread-123";

			// Action
			const isExist = await threadRepositoryPostgres.checkIfThreadExist(threadId);
			expect(isExist).toBe(false);
		});
	});

	describe("getThreadDetails function", () => {
		it("should return thread details if thread with given id is found", async () => {
			// Arrange
			await ThreadsTableTestHelper.addThread({});

			const threadRepositoryPostgres = new ThreadRepositoryPostgres(pool, () => {});
			const threadId = "thread-123";

			// Action
			const thread = await threadRepositoryPostgres.getThreadDetails(threadId);

			// Assert
			expect(thread).toBeDefined();
			expect(thread.id).toEqual(threadId);
			expect(thread).toHaveProperty("title");
			expect(thread).toHaveProperty("body");
			expect(thread).toHaveProperty("date");
			expect(thread).toHaveProperty("username");
		});
	});
});
