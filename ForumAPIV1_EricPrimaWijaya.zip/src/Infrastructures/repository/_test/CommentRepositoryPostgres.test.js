const UsersTableTestHelper = require("../../../../tests/UsersTableTestHelper");
const ThreadsTableTestHelper = require("../../../../tests/ThreadsTableTestHelper");
const CommentsTableTestHelper = require("../../../../tests/CommentsTableTestHelper");
const CreateComment = require("../../../Domains/comments/entities/CreateComment");
const CommentRepositoryPostgres = require("../CommentRepositoryPostgres");
const pool = require("../../database/postgres/pool");
const DeleteComment = require("../../../Domains/comments/entities/DeleteComment");
const RepliesTableTestHelper = require("../../../../tests/RepliesTableTestHelper");

describe("CommentRepositoryPostgres", () => {
	beforeEach(async () => {
		// Insert new user to users table (Owner of new thread)
		await UsersTableTestHelper.addUser({}); // id of user-123

		// Insert new thread with id of thread-123
		await ThreadsTableTestHelper.addThread({});
	});

	afterEach(async () => {
		await RepliesTableTestHelper.cleanTable();
		await CommentsTableTestHelper.cleanTable();
		await ThreadsTableTestHelper.cleanTable();
		await UsersTableTestHelper.cleanTable();
	});

	afterAll(async () => {
		await CommentsTableTestHelper.cleanTable();
		await ThreadsTableTestHelper.cleanTable();
		await UsersTableTestHelper.cleanTable();
		await pool.end();
	});

	describe("addComment function", () => {
		it("should persist create comment and return created comment correctly", async () => {
			// Arrange
			const createComment = new CreateComment({
				content: "comment content",
				threadId: "thread-123"
			});
			const userId = "user-123";
			const fakeIdGenerator = () => "123";
			const commentRepositoryPostgres = new CommentRepositoryPostgres(pool, fakeIdGenerator);

			// Action
			await commentRepositoryPostgres.addComment(userId, createComment);

			// Assert
			const comment = await CommentsTableTestHelper.findCommentsById("comment-123");
			expect(comment).toHaveLength(1);
		});
	});

	describe("checkIfCommentExist function", () => {
		it("should return true if comment exist", async () => {
			// Arrange
			// Insert comment with id of "comment-123" to thread "thread-123"
			await CommentsTableTestHelper.addComment({});

			const commentId = "comment-123";
			const threadId = "thread-123";
			const commentRepositoryPostgres = new CommentRepositoryPostgres(pool, () => {});

			// Action
			const isExist = await commentRepositoryPostgres.checkIfCommentExist(commentId, threadId);

			// Assert
			expect(isExist).toBe(true);
		});

		it("should return false if comment not exist", async () => {
			// Arrange
			const commentId = "comment-123";
			const threadId = "thread-123";
			const commentRepositoryPostgres = new CommentRepositoryPostgres(pool, () => {});

			// Action
			const isExist = await commentRepositoryPostgres.checkIfCommentExist(commentId, threadId);

			// Assert
			expect(isExist).toBe(false);
		});
	});

	describe("validateCommentOwner function", () => {
		it("should return true if user is the owner of the comment", async () => {
			// Arrange
			// Insert comment with id of "comment-123" and owner of "user-123"
			await CommentsTableTestHelper.addComment({});

			const commentId = "comment-123";
			const userId = "user-123";
			const commentRepositoryPostgres = new CommentRepositoryPostgres(pool, () => {});

			// Action
			const isOwner = await commentRepositoryPostgres.validateCommentOwner(commentId, userId);

			// Assert
			expect(isOwner).toBe(true);
		});

		it("should return false if user is not the owner of the comment", async () => {
			// Arrange
			// Insert comment with id of "comment-123" and owner of "user-123"
			await CommentsTableTestHelper.addComment({});

			const commentId = "comment-123";
			const userId = "user-456"; // not valid owner
			const commentRepositoryPostgres = new CommentRepositoryPostgres(pool, () => {});

			// Action
			const isOwner = await commentRepositoryPostgres.validateCommentOwner(commentId, userId);

			// Assert
			expect(isOwner).toBe(false);
		});
	});

	describe("deleteComment function", () => {
		it("should persist delete comment ran successfully", async () => {
			// Arrange
			// Insert comment with id of "comment-123" and owner of "user-123"
			await CommentsTableTestHelper.addComment({});

			const deleteComment = new DeleteComment({
				threadId: "thread-123",
				commentId: "comment-123"
			});
			const userId = "user-123";
			const commentRepositoryPostgres = new CommentRepositoryPostgres(pool, () => {});

			// Action
			await commentRepositoryPostgres.deleteComment(userId, deleteComment);

			// Assert
			const comments = await CommentsTableTestHelper.findCommentsById("comment-123");
			expect(comments[0].is_delete).toBe(true);
		});
	});

	describe("getThreadComments function", () => {
		it("should return array of thread comments", async () => {
			// Arrange
			// Insert new users
			await UsersTableTestHelper.addUser({ id: "user-234", username: "dicoding 2" });

			// Insert multiple comments
			await CommentsTableTestHelper.addComment({});
			await CommentsTableTestHelper.addComment({
				id: "comment-234",
				userId: "user-234",
				isDelete: true
			});

			const commentRepositoryPostgres = new CommentRepositoryPostgres(pool, () => {});

			// Action
			const threadId = "thread-123";
			const comments = await commentRepositoryPostgres.getThreadComments(threadId);

			// Assert
			const [comment1, comment2] = comments;

			expect(comments).toHaveLength(2);

			expect(comment1.id).toBe("comment-123");
			expect(comment1.username).toBe("dicoding");
			expect(comment1.content).toBe("comment content");

			expect(comment2.id).toBe("comment-234");
			expect(comment2.username).toBe("dicoding 2");
			expect(comment2.content).toBe("**komentar telah dihapus**");
		});
	});

	it("should include replies of each comment", async () => {
		// Arrange
		// Insert new users
		await UsersTableTestHelper.addUser({ id: "user-234", username: "dicoding 2" });

		// Insert multiple comments
		await CommentsTableTestHelper.addComment({});
		await CommentsTableTestHelper.addComment({
			id: "comment-234",
			userId: "user-234",
			isDelete: true
		});

		// Insert multiple replies
		await RepliesTableTestHelper.addReply({});
		await RepliesTableTestHelper.addReply({
			id: "reply-234",
			userId: "user-234",
			isDelete: true
		});

		const commentRepositoryPostgres = new CommentRepositoryPostgres(pool, () => {});

		// Action
		const threadId = "thread-123";
		const comments = await commentRepositoryPostgres.getThreadComments(threadId);

		// Assert
		const [comment1, comment2] = comments;
		const [reply1, reply2] = comment1.replies;

		expect(comment1.replies).toHaveLength(2);
		expect(reply1.id).toBe("reply-123");
		expect(reply1.content).toBe("reply content");
		expect(reply1.username).toBe("dicoding");

		expect(reply2.id).toBe("reply-234");
		expect(reply2.content).toBe("**balasan telah dihapus**");
		expect(reply2.username).toBe("dicoding 2");

		expect(comment2.replies).toHaveLength(0);
	});
});
