const CommentRepository = require("../../Domains/comments/CommentRepository");
const CreatedComment = require("../../Domains/comments/entities/CreatedComment");

class CommentRepositoryPostgres extends CommentRepository {
	constructor(pool, idGenerator) {
		super();
		this._pool = pool;
		this._idGenerator = idGenerator;
	}

	async addComment(userId, createComment) {
		const { content, threadId } = createComment;
		const commentId = `comment-${this._idGenerator()}`;

		const query = {
			text: "INSERT INTO comments VALUES($1, $2, $3, $4) RETURNING id, content, owner",
			values: [commentId, threadId, userId, content]
		};

		const result = await this._pool.query(query);

		return new CreatedComment({ ...result.rows[0] });
	}

	async checkIfCommentExist(commentId, threadId) {
		const query = {
			text: "SELECT id FROM comments WHERE id = $1 AND thread_id = $2",
			values: [commentId, threadId]
		};

		const result = await this._pool.query(query);

		return result.rowCount > 0;
	}

	async validateCommentOwner(commentId, userId) {
		const query = {
			text: "SELECT owner FROM comments WHERE id = $1",
			values: [commentId]
		};

		const result = await this._pool.query(query);

		return result.rows[0].owner === userId;
	}

	async deleteComment(userId, deleteComment) {
		const { threadId, commentId } = deleteComment;

		const query = {
			text: "UPDATE comments SET is_delete = true WHERE thread_id = $1 AND id = $2 AND owner = $3",
			values: [threadId, commentId, userId]
		};

		await this._pool.query(query);
	}

	async getThreadComments(threadId) {
		const query = {
			text: `
        SELECT c.id, u.username, c.date, 
          CASE WHEN c.is_delete = true 
            THEN '**komentar telah dihapus**'
            ELSE c.content
          END as content,
          (SELECT COALESCE(json_agg(
            json_build_object(
                'id', r.id,
                'content', 
                CASE WHEN r.is_delete = true 
                  THEN '**balasan telah dihapus**'
                  ELSE r.content
                END,
                'date', r.date,
                'username', u2.username
            )
            ORDER BY r.date ASC
          ), '[]')
          FROM replies r
          JOIN users u2 ON r.owner = u2.id
          WHERE r.comment_id = c.id
          ) as replies
        FROM comments c 
        JOIN users u ON c.owner = u.id
        WHERE c.thread_id = $1
        ORDER BY c.date ASC
      `,
			values: [threadId]
		};

		const comments = await this._pool.query(query);

		return comments.rows;
	}
}

module.exports = CommentRepositoryPostgres;
