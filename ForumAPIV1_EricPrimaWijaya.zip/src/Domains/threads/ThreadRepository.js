class ThreadRepository {
	async addThread(createThread) {
		throw new Error("THREAD_REPOSITORY.METHOD_NOT_IMPLEMENTED");
	}

	async checkIfThreadExist(threadId) {
		throw new Error("THREAD_REPOSITORY.METHOD_NOT_IMPLEMENTED");
	}

	async getThreadDetails(threadId) {
		throw new Error("THREAD_REPOSITORY.METHOD_NOT_IMPLEMENTED");
	}
}

module.exports = ThreadRepository;
