const CommentUseCase = require("../../../../Applications/use_case/CommentUseCase");

class CommentHandler {
	constructor(container) {
		this._container = container;

		this.postThreadCommentHandler = this.postThreadCommentHandler.bind(this);
		this.deleteThreadCommentHandler = this.deleteThreadCommentHandler.bind(this);
	}

	async postThreadCommentHandler(request, h) {
		const { id: userId } = request.auth.credentials;
		const { threadId } = request.params;
		const commentUseCase = this._container.getInstance(CommentUseCase.name);
		const addedComment = await commentUseCase.addComment(userId, {
			...request.payload,
			threadId: threadId
		});

		const response = h.response({
			status: "success",
			data: {
				addedComment
			}
		});
		response.code(201);
		return response;
	}

	async deleteThreadCommentHandler(request, h) {
		const { id: userId } = request.auth.credentials;
		const { threadId, commentId } = request.params;
		const commentUseCase = this._container.getInstance(CommentUseCase.name);

		await commentUseCase.deleteComment(userId, {
			threadId,
			commentId
		});

		const response = h.response({
			status: "success"
		});
		return response;
	}
}

module.exports = CommentHandler;
