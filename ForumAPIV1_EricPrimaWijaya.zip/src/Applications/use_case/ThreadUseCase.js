const NotFoundError = require("../../Commons/exceptions/NotFoundError");
const CreateThread = require("../../Domains/threads/entities/CreateThread");

class ThreadUseCase {
	constructor({ threadRepository, commentRepository }) {
		this._threadRepository = threadRepository;
		this._commentRepository = commentRepository;
	}

	async addThread(userId, useCasePayload) {
		const createThread = new CreateThread(useCasePayload);
		const createdThread = await this._threadRepository.addThread(userId, createThread);

		return createdThread;
	}

	async getThreadDetails(useCasePayload) {
		const { threadId } = useCasePayload;

		// Check if thread exist
		const isThreadExist = await this._threadRepository.checkIfThreadExist(threadId);

		if (!isThreadExist) {
			throw new NotFoundError(`Thread dengan id '${threadId}' tidak ditemukan!`);
		}

		const threadDetails = await this._threadRepository.getThreadDetails(threadId);
		const threadComments = await this._commentRepository.getThreadComments(threadId);

		return {
			...threadDetails,
			comments: threadComments
		};
	}
}

module.exports = ThreadUseCase;
