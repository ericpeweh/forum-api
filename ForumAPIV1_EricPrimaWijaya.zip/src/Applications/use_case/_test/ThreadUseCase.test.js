const UsersTableTestHelper = require("../../../../tests/UsersTableTestHelper");
const CreatedThread = require("../../../Domains/threads/entities/CreatedThread");
const CreateThread = require("../../../Domains/threads/entities/CreateThread");
const ThreadRepository = require("../../../Domains/threads/ThreadRepository");
const CommentRepository = require("../../../Domains/comments/CommentRepository");
const ThreadUseCase = require("../ThreadUseCase");

describe("ThreadUseCase", () => {
	beforeAll(async () => {
		await UsersTableTestHelper.addUser({});
	});

	afterAll(async () => {
		await UsersTableTestHelper.cleanTable();
	});

	it("should orchestrating the add thread action correctly", async () => {
		// Arrange
		const useCasePayload = {
			title: "thread title",
			body: "thread body"
		};
		const userId = "user-123";

		const mockCreatedThread = new CreatedThread({
			id: "thread-123",
			title: useCasePayload.title,
			body: useCasePayload.body,
			owner: userId
		});

		// Create dependency of use case
		const mockThreadRepository = new ThreadRepository();

		// Mock needed function
		mockThreadRepository.addThread = jest
			.fn()
			.mockImplementation(() => Promise.resolve(mockCreatedThread));

		// Create use case instance
		const threadUseCase = new ThreadUseCase({ threadRepository: mockThreadRepository });

		// Action
		const createdThread = await threadUseCase.addThread(userId, useCasePayload);

		// Assert
		expect(createdThread).toStrictEqual(
			new CreatedThread({
				id: "thread-123",
				title: useCasePayload.title,
				owner: userId
			})
		);

		expect(mockThreadRepository.addThread).toBeCalledWith(
			userId,
			new CreateThread({
				title: useCasePayload.title,
				body: useCasePayload.body
			})
		);
	});

	it("should orchestrating the get thread details action correctly", async () => {
		// Arrange
		const useCasePayload = {
			threadId: "thread-123"
		};

		const mockThreadDetails = {
			id: "thread-123",
			title: "thread title",
			body: "thread body",
			date: new Date().toISOString(),
			username: "dicoding"
		};

		const mockThreadComments = [
			{
				id: "comment-123",
				username: "dicoding",
				date: new Date().toISOString(),
				content: "sebuah comment"
			},
			{
				id: "comment-234",
				username: "dicoding 2",
				date: new Date().toISOString(),
				content: "**komentar telah dihapus**"
			}
		];

		// Create dependency of use case
		const mockThreadRepository = new ThreadRepository();
		const mockCommentRepository = new CommentRepository();

		// Mock needed function
		mockThreadRepository.getThreadDetails = jest
			.fn()
			.mockImplementation(() => Promise.resolve(mockThreadDetails));

		mockThreadRepository.checkIfThreadExist = jest
			.fn()
			.mockImplementation(() => Promise.resolve(true));

		mockCommentRepository.getThreadComments = jest
			.fn()
			.mockImplementation(() => Promise.resolve(mockThreadComments));

		// Create use case instance
		const threadUseCase = new ThreadUseCase({
			threadRepository: mockThreadRepository,
			commentRepository: mockCommentRepository
		});

		// Action
		const threadDetails = await threadUseCase.getThreadDetails(useCasePayload);

		// Assert
		expect(threadDetails).toEqual({
			...mockThreadDetails,
			comments: mockThreadComments
		});
		expect(mockThreadRepository.checkIfThreadExist).toBeCalledWith(useCasePayload.threadId);
		expect(mockThreadRepository.getThreadDetails).toBeCalledWith(useCasePayload.threadId);
		expect(mockCommentRepository.getThreadComments).toBeCalledWith(useCasePayload.threadId);
	});
});
