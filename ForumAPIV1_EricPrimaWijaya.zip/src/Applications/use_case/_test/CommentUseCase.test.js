const UsersTableTestHelper = require("../../../../tests/UsersTableTestHelper");
const CreatedComment = require("../../../Domains/comments/entities/CreatedComment");
const CreateComment = require("../../../Domains/comments/entities/CreateComment");
const CommentRepository = require("../../../Domains/comments/CommentRepository");
const CommentUseCase = require("../CommentUseCase");
const ThreadRepository = require("../../../Domains/threads/ThreadRepository");
const DeleteComment = require("../../../Domains/comments/entities/DeleteComment");

describe("CommentUseCase", () => {
	beforeAll(async () => {
		await UsersTableTestHelper.addUser({});
	});

	afterAll(async () => {
		await UsersTableTestHelper.cleanTable();
	});

	it("should orchestrating the add comment action correctly", async () => {
		// Arrange
		const useCasePayload = {
			content: "comment content",
			threadId: "thread-123"
		};
		const userId = "user-123";

		const mockCreatedComment = new CreatedComment({
			id: "comment-123",
			content: "comment content",
			owner: "user-123"
		});

		// Create dependency of use case
		const mockCommentRepository = new CommentRepository();
		const mockThreadRepository = new ThreadRepository();

		// Mock needed function
		mockCommentRepository.addComment = jest
			.fn()
			.mockImplementation(() => Promise.resolve(mockCreatedComment));

		mockThreadRepository.checkIfThreadExist = jest
			.fn()
			.mockImplementation(() => Promise.resolve(true));

		// Create use case instance
		const commentUseCase = new CommentUseCase({
			commentRepository: mockCommentRepository,
			threadRepository: mockThreadRepository
		});

		// Action
		const createdComment = await commentUseCase.addComment(userId, useCasePayload);

		// Assert
		expect(createdComment).toStrictEqual(
			new CreatedComment({
				id: "comment-123",
				content: useCasePayload.content,
				owner: userId
			})
		);

		expect(mockThreadRepository.checkIfThreadExist).toBeCalledWith(useCasePayload.threadId);

		expect(mockCommentRepository.addComment).toBeCalledWith(
			userId,
			new CreateComment({
				content: useCasePayload.content,
				threadId: useCasePayload.threadId
			})
		);
	});

	it("should orchestrating the delete comment action correctly", async () => {
		// Arrange
		const useCasePayload = {
			threadId: "thread-123",
			commentId: "comment-123"
		};
		const userId = "user-123";

		// Create dependency of use case
		const mockCommentRepository = new CommentRepository();
		const mockThreadRepository = new ThreadRepository();

		// Mock needed function
		mockCommentRepository.checkIfCommentExist = jest
			.fn()
			.mockImplementation(() => Promise.resolve(true));

		mockCommentRepository.validateCommentOwner = jest
			.fn()
			.mockImplementation(() => Promise.resolve(true));

		mockCommentRepository.deleteComment = jest.fn().mockImplementation(() => Promise.resolve());

		mockThreadRepository.checkIfThreadExist = jest
			.fn()
			.mockImplementation(() => Promise.resolve(true));

		// Create use case instance
		const commentUseCase = new CommentUseCase({
			commentRepository: mockCommentRepository,
			threadRepository: mockThreadRepository
		});

		// Action
		await commentUseCase.deleteComment(userId, useCasePayload);

		// Assert
		expect(mockThreadRepository.checkIfThreadExist).toBeCalledWith(useCasePayload.threadId);
		expect(mockCommentRepository.checkIfCommentExist).toBeCalledWith(
			useCasePayload.commentId,
			useCasePayload.threadId
		);
		expect(mockCommentRepository.validateCommentOwner).toBeCalledWith(
			useCasePayload.commentId,
			userId
		);
		expect(mockCommentRepository.deleteComment).toBeCalledWith(
			userId,
			new DeleteComment({
				threadId: useCasePayload.threadId,
				commentId: useCasePayload.commentId
			})
		);
	});
});
